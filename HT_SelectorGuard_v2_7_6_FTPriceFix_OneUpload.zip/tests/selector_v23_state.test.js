'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs'),vm=require('node:vm');
const html=fs.readFileSync('app/src/main/assets/selector.html','utf8');
const script=html.split('<script>')[1].split('</script>')[0];
new vm.Script(script);
assert(script.includes("switchPeriod('HT',true)"),'cold start always opens HT scanning');
assert(!script.includes("el('periodFT').addEventListener"),'FT scan tab is no longer interactive');
const snaps=new Map(),stored=new Map([['mode','FT']]);
function run(){
 const els=new Map();
 const element=id=>{if(!els.has(id))els.set(id,{value:id==='minOdd'?'4':id==='day'?'2026-11-23':'',textContent:'',innerHTML:'',checked:false,disabled:false,style:{},classList:{toggle(){},add(){},remove(){}},addEventListener(){},setAttribute(){},querySelectorAll(){return []}});return els.get(id)};
 const monitor={getKey:()=>'',selectedMatches:()=> '[]',saveSnapshot:(mode,json)=>{snaps.set(mode,json);return 'OK'},loadSnapshot:mode=>snaps.get(mode)||'',lastPageMode:()=>stored.get('mode')||'FT',setPageMode:mode=>stored.set('mode',mode),openMonitor(){}};
 const ctx={document:{body:{classList:{toggle(){}}},getElementById:element,addEventListener(){},hidden:false},localStorage:{getItem:k=>stored.get(k)||null,setItem:(k,v)=>stored.set(k,v),removeItem:k=>stored.delete(k)},AndroidMonitor:monitor,console,Date,Intl,Math,Map,Set,Number,JSON,Object,Array,Error,RegExp,String,Boolean,parseFloat,parseInt,URLSearchParams,Blob,TextEncoder,setTimeout(fn){fn()}};
 ctx.window=ctx;ctx.globalThis=ctx;
 vm.runInNewContext(script.replace(/\}\)\(\);\s*$/,`globalThis.Test={app,saveSelectorSnapshot};})();`),ctx);
 return ctx.Test;
}
let first=run();assert.equal(first.app.period,'HT');assert.equal(first.saveSelectorSnapshot(true),true);
assert(snaps.has('HT'));assert(!snaps.has('FT'));
let second=run();assert.equal(second.app.period,'HT');
assert.equal(second.app.ranked.length,0);
console.log('PASS: only HT scanning on cold start, HT snapshot storage preserved, FT scan disabled');
