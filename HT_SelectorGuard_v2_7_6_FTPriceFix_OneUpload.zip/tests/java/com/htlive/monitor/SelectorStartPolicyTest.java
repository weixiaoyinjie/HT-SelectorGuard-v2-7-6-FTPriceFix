package com.htlive.monitor;
public final class SelectorStartPolicyTest {
    private static void check(boolean ok,String why){if(!ok)throw new AssertionError(why);}
    public static void main(String[] args){
        long k=1_700_000_000_000L;
        check(SelectorStartPolicy.startAt(k)==k+180_000L,"three-minute offset");
        check(!SelectorStartPolicy.startDue(k+179_999L,k),"not immediately after choosing");
        check(SelectorStartPolicy.startDue(k+180_000L,k),"schedule starts at +3");
        check(!SelectorStartPolicy.allowMatchAlerts(true,"NS",3),"delayed match cannot alert");
        check(!SelectorStartPolicy.allowMatchAlerts(true,"1H",2),"selector cannot alert before minute 3");
        check(SelectorStartPolicy.allowMatchAlerts(true,"1H",3),"selector can alert from 3");
        check(SelectorStartPolicy.allowMatchAlerts(true,"1H",15),"later checkpoints preserved");
        check(SelectorStartPolicy.allowMatchAlerts(false,"1H",1),"legacy flow preserved");
        System.out.println("PASS: selector +3m gate");
    }
}
