package com.htlive.monitor;
import org.json.JSONObject;
import org.json.JSONArray;
public final class Watch8CompanionPayloadTest {
    private static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
    public static void main(String[] args) throws Exception {
        JSONObject m=new JSONObject().put("home","曼彻斯特联队").put("away","切尔西")
            .put("h","1").put("a","0").put("minute",36)
            .put("guardRisk",new JSONObject().put("level","HIGH")
                .put("items",new JSONArray().put(new JSONObject()))
                .put("hit",1).put("pending",1).put("broken",0));
        JSONObject risk=Watch8CompanionPayload.create("101",230,"🛡 守分风险",m,System.currentTimeMillis(),"",true);
        check("101".equals(risk.optString("fixture")),"fixture lost");
        check("1-0".equals(risk.optString("score")),"score wrong");
        check(risk.optString("line1").contains("36'"),"live minute missing");
        check(risk.optString("line2").contains("命中1"),"risk states missing");
        check(risk.optString("line3").contains("高风险"),"action missing");
        check(!risk.optBoolean("timed"),"risk misclassified");
        JSONObject timed=Watch8CompanionPayload.create("101",231,"第15分钟定点复核",m,System.currentTimeMillis(),"",true);
        check(timed.optBoolean("timed"),"checkpoint misclassified");
        check(timed.optString("kind").contains("15'"),"planned mark lost");
        check(timed.optString("line1").contains("36'"),"real minute missing");
        check(timed.optString("line2").contains("统计缺失或滞后"),"stale warning omitted");
        JSONObject complete=Watch8CompanionPayload.create("101",240,"🛡 守分风险",m,
            System.currentTimeMillis(),"",true,"手机通知原始正文","手机详细分析 xG 射门与比分路径");
        check(complete.optString("phoneBody").equals("手机通知原始正文"),"watch must receive original phone notification");
        check(complete.optString("phoneDetail").contains("xG"),"watch full detail lost");
        check(complete.optString("teams").contains("切尔西"),"full team names lost");
        JSONObject exact=Watch8CompanionPayload.create("101",241,"🛡 守分风险",m,
            System.currentTimeMillis(),"",true,"手机完整通知标题", "手机通知预览",
            "手机完整通知正文", "来自手机版的完整分析详情");
        check("手机完整通知标题".equals(exact.optString("phoneTitle")),"phone title differs on watch");
        check("手机通知预览".equals(exact.optString("phonePreview")),"phone preview differs on watch");
        check("手机完整通知正文".equals(exact.optString("phoneBody")),"phone body differs on watch");
        check("来自手机版的完整分析详情".equals(exact.optString("phoneDetail")),"phone detail differs on watch");
        JSONObject empty=Watch8CompanionPayload.create("7",232,"⚽ 进球",null,System.currentTimeMillis(),"",true);
        check("?-?".equals(empty.optString("score")),"unavailable score invented");
        check(!empty.optString("line2").equals(empty.optString("line3")),"duplicate lines");
        System.out.println("44mm companion payload tests OK");
    }
}
