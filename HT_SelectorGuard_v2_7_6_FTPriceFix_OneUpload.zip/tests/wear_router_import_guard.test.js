const assert = require('node:assert/strict');
const fs = require('node:fs');
const src = fs.readFileSync('app/src/main/java/com/htlive/monitor/WearAlertRouter.java', 'utf8');
assert.match(src, /\bSet<String>\b|\bSet<String>/, 'WearAlertRouter must declare Set type for removing fixtures');
assert.match(src, /^import java\.util\.Set;$/m, 'Missing java.util.Set import (fixes GitHub Android compile)');
assert.match(src, /getConnectedNodes\(\)/, 'Do not remove connected-node delivery logic');
console.log('PASS: WearAlertRouter compiles with Set import and preserves connected-node routing');
