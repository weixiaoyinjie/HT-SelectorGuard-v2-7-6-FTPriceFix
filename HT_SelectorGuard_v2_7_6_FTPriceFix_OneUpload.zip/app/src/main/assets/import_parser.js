/* v1.9: OCR screenshot fixture IDs always require API verification. */
(function(root){
'use strict';
const ALIASES={
  'stadelavallois':['laval','lavallois','stadelaval'],
  'lavallois':['laval'],
  'laval':['lavallois','stadelavallois'],
  'grenoblefoot38':['grenoble'],
  'grenoble':['grenoblefoot38'],
  'asnancy':['nancy','asnancylorraine'],
  'asnancylorraine':['nancy'],
  'nancylorraine':['nancy'],
  'annecyfc':['annecy'],
  'fcgrenoble':['grenoble'],
  'clermontfoot63':['clermontfoot','clermont'],
  'randersfc':['randers'],
  'achorsens':['horsens'],
  'tallerescordoba':['talleres','talleresdecordoba'],
  'talleresdecordoba':['tallerescordoba'],
  'bocajuniors':['boca'],
  'deportivocuenca':['cuenca'],
  'tecnicouniversitario':['tecnico universitario','tecnicouniversitario'],
  'boulogne':['usboulogne','usboulognecotedopale'],
  'usboulogne':['boulogne'],
  'grenoblefoot':['grenoble']
};
const STOP=new Set(['fc','ac','as','afc','cf','sc','club','foot','football','stadium','stade','de','da','do','the','united','city','sporting','team']);
function norm(s){return String(s||'').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9\u4e00-\u9fff]+/g,'')}
function tokens(s){return String(s||'').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().split(/[^a-z0-9\u4e00-\u9fff]+/).filter(x=>x.length>=3&&!STOP.has(x))}
function fixDate(raw){if(!raw)return '';const m=raw.match(/(20\d{2})\s*[-/.年]\s*(\d{1,2})\s*[-/.月]\s*(\d{1,2})/);if(!m)return '';const date=`${m[1]}-${m[2].padStart(2,'0')}-${m[3].padStart(2,'0')}`;return Number.isFinite(Date.parse(date+'T12:00:00Z'))?date:''}
function argTime(v){const m=String(v||'').match(/\b([01]?\d|2[0-3])\s*[:：.]\s*([0-5]\d)\b/);return m?`${m[1].padStart(2,'0')}:${m[2]}`:''}
function lineSort(lines){
 // Green kickoff headings and white match labels MUST be processed together.
 // The two streams contain disjoint colors, so never select just one OCR source.
 const input=(lines||[]).filter(l=>l&&String(l.t||'').trim()&&Number.isFinite(+l.y)
     && (!l.color || l.color==='green' || l.color==='white'));
 const items=input.slice().sort((a,b)=>+a.y-+b.y||+a.x-+b.x),groups=[];
 for(const l of items){
   const y=+l.y+(+l.h||18)/2,h=Math.max(8,+l.h||18);
   let group=groups.find(g=>g.color===(l.color||'mixed')&&
       Math.abs(g.y-y)<=Math.max(5,Math.min(15,Math.min(g.h,h)*.50)));
   if(group){group.p.push(l);group.y=(group.y*(group.p.length-1)+y)/group.p.length}
   else groups.push({y,h,color:l.color||'mixed',p:[l]});
 }
 const rows=groups.sort((a,b)=>a.y-b.y).map(g=>({
   y:g.y,color:g.color,text:g.p.sort((a,b)=>+a.x-+b.x).map(x=>x.t).join(' ').trim()
 }));
 const seen=new Set();
 return rows.filter(row=>{const key=row.color+'|'+Math.round(row.y/8)+'|'+norm(row.text);
    if(seen.has(key))return false;seen.add(key);return true;}).map(x=>x.text);
}
function rowsFrom(photo){
 const ocrText=String(photo.ocrText||'');
 const fromText=ocrText.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
 if(photo.ocrEdited)return fromText;
 const rows=lineSort(photo.ocrLines||[]);
 if(rows.length>=2)return rows;
 return fromText;
}
function trimSide(s){return String(s||'').split(/[|｜丨]/)[0].split(/\s+半场\s*/)[0].split(/\s+赔率\s*/)[0].replace(/[，。•·]+$/,'').trim()}
function isTeamLine(s){return /\s+v(?:s|\.)?\.?\s+/i.test(s)&&/[a-z]{3}/i.test(s)}
function parseSides(row){
 const text=String(row||'').replace(/\s+/g,' ').trim();
 const piece=trimSide(text).split(/\s+v(?:s|\.)?\.?\s+/i);
 if(piece.length!==2)return null;
 let home=piece[0].replace(/^[✓✔\-–•\s]+/,'').trim(),away=piece[1].trim();
 if(home.length<3||away.length<3||!/[a-z]{3}/i.test(home)||!/[a-z]{3}/i.test(away))return null;
 // Remove page headings, but never infer the fixture from a full-page string.
 if(home.length>55||away.length>55)return null;
 return {home,away};
}
function readFixtureId(row){
 const s=String(row||'').replace(/[Ｉｌ|]/g,'I').replace(/[：﹕]/g,':');
 const m=s.match(/\bfixture\s*(?:I[D0]|1D|lD)?\s*[:#-]?\s*([0-9Oo]{5,10})\b/i);
 return m?m[1].replace(/[Oo]/g,'0'):'';
}
function parse(photo){
 const rows=rowsFrom(photo),items=[],seen=new Set(),seenIds=new Set();
 let date='',time='',groupTotal=0,lastItem=null,pendingFixtureId='',awaitingNumber=false;
 const makeItem=(part,row,fid='')=>({home:part?.home||'',away:part?.away||'',date,time,
     fixtureId:fid,sourceRow:row});
 for(let i=0;i<rows.length;i++){
  const row=String(rows[i]||'').trim();if(!row)continue;
  let fid=readFixtureId(row);
  if(!fid && awaitingNumber){
    const split=row.match(/^\s*([0-9]{5,10})\s*$/);
    if(split)fid=split[1];
    awaitingNumber=false;
  }
  if(fid){
    // OCR often returns both masked and original-language versions of the same ID.
    // Never overwrite a prior match's ID with the next card's ID.
    if(seenIds.has(fid))continue;
    seenIds.add(fid);
    if(lastItem && !lastItem.fixtureId && !pendingFixtureId){
      lastItem.fixtureId=fid;
    }else{
      pendingFixtureId=fid;
      lastItem=null;
    }
    continue;
  }
  if(/\bfixture\s*(?:I[D0]|1D|lD)?\s*[:#-]?\s*$/i.test(row)){
    awaitingNumber=true;continue;
  }
  const d=fixDate(row),clock=argTime(row),header=/开赛|开球|kick\s*off|比赛时间/i.test(row);
  if(d&&clock){date=d;time=clock;lastItem=null;
    const cnt=row.match(/(\d{1,2})\s*场/);if(cnt)groupTotal+=+cnt[1];continue;}
  if(d&&!isTeamLine(row)){date=d;time='';lastItem=null;continue;}
  if(header&&clock&&!isTeamLine(row)){time=clock;lastItem=null;continue;}
  let part=parseSides(row),source=row;
  // When OCR splits a team-vs-team label into 2 or 3 lines, join only nearby
  // consecutive rows; do not merge date headings or unrelated match cards.
  if(!part && i+1<rows.length && !fixDate(rows[i+1])){
    let joined=row+' '+rows[i+1];
    part=(/\bvs?\.?\b/i.test(row) || /^\s*v(?:s|\.)?\b/i.test(rows[i+1]))?parseSides(joined):null;
    if(part){source=joined;i++;}
    else if(i+2<rows.length && !fixDate(rows[i+2]) &&
        /^\s*v(?:s|\.)?\s*$/i.test(rows[i+1])){
      joined=row+' vs '+rows[i+2];part=parseSides(joined);
      if(part){source=joined;i+=2;}
    }
  }
  if(!part)continue;
  const key=[date,time,norm(part.home),norm(part.away)].join('|');
  if(seen.has(key))continue;
  seen.add(key);
  const item=makeItem(part,source,pendingFixtureId);
  pendingFixtureId='';lastItem=item;items.push(item);
 }
 // An ID-only card is eligible for exact API verification ONLY when the
 // screenshot supplies both kickoff date and time. No guessing across dates.
 if(pendingFixtureId&&date&&time && !items.some(x=>x.fixtureId===pendingFixtureId))
   items.push(makeItem(null,'Fixture ID '+pendingFixtureId,pendingFixtureId));
 const fallbackDate=fixDate(photo.ocrText||'');
 return {items:items.map(x=>({...x,date:x.date||fallbackDate})),rows,
     groupTotal,extractedTotal:items.length,hasDate:!!fallbackDate};
}
function nameScore(ocr,api){
 const a=norm(ocr),b=norm(api);if(!a||!b)return 0;
 if(a===b)return 10;
 if((a.length>=5&&b.includes(a))||(b.length>=5&&a.includes(b)))return 8;
 if((ALIASES[a]||[]).some(x=>norm(x)===b)||(ALIASES[b]||[]).some(x=>norm(x)===a))return 9;
 const t=tokens(ocr),u=tokens(api);let best=0;
 for(const v of t)for(const w of u){if(v===w&&v.length>=5)best=Math.max(best,7);
   else if(v.length>=6&&w.length>=6&&(v.startsWith(w)||w.startsWith(v)))best=Math.max(best,6.5);}
 return best;
}
function fixtureLocalDateTime(iso){if(!iso)return {date:'',time:''};
 const d=new Date(iso);if(isNaN(d.getTime()))return {date:'',time:''};
 // Avoid locale-dependent en-CA date formatting. Argentina has UTC-3 (no DST).
 const parts=new Intl.DateTimeFormat('en-US',{timeZone:'America/Argentina/Buenos_Aires',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false}).formatToParts(d);
 const o=Object.fromEntries(parts.map(p=>[p.type,p.value]));return {date:`${o.year}-${o.month}-${o.day}`,time:`${o.hour==='24'?'00':o.hour}:${o.minute}`};
}
function match(parsed,candidates){
 const out=[],issues=[],used=new Set(),api=Array.isArray(candidates)?candidates:[];
 for(const item of parsed.items){
  const possible=[];
  for(const f of api){
   // A detected ID is authoritative as a lookup key, but not proof by itself.
   // Never silently substitute a different ID based on fuzzy team-name matching.
   if(item.fixtureId && String(f.id)!==String(item.fixtureId))continue;
   const a=nameScore(item.home,f.home),b=nameScore(item.away,f.away);
   const dt=fixtureLocalDateTime(f.kickoff);
   if(item.date && item.date!==dt.date)continue;
   let minuteGap=9999;
   if(item.time){
    const [hh,mm]=item.time.split(':').map(Number),[fh,fm]=dt.time.split(':').map(Number);
    if(!Number.isFinite(fh))continue;
    minuteGap=Math.abs(hh*60+mm-(fh*60+fm));
    if(minuteGap>15)continue;
   }
   const namesAgree=a>=6.5&&b>=6.5;
   // Strong fixture ID + exact date+time can rescue partially unreadable names.
   // Without an ID, require BOTH names (not just a kickoff time).
   if(!namesAgree && !(item.fixtureId && item.date && item.time && minuteGap<=2))continue;
   possible.push({...f,confidence:a+b+(item.fixtureId?10:0),matchedItem:item});
  }
  possible.sort((a,b)=>b.confidence-a.confidence);
  // Must have a unique API fixture for this specific team pair/date/time.
  if(!possible.length){issues.push({item,reason:item.fixtureId?'Fixture ID '+item.fixtureId+' 未通过 API 校验（队名或时间不符）':'没有找到队名和开赛时间同时吻合的 API 比赛'});continue;}
  if(possible.length>1 && (possible[0].confidence-possible[1].confidence<2)){
    issues.push({item,reason:'有多个相近赛事，需人工核对'});continue;
  }
  const best=possible[0],id=String(best.id);
  if(!/^[0-9]+$/.test(id)){issues.push({item,reason:'比赛没有有效API ID'});continue;}
  if(used.has(id)){issues.push({item,reason:'同一比赛重复出现，已去重'});continue;}
  used.add(id);out.push(best);
 }
 return {matched:out,issues,found:parsed.items.length,groupTotal:parsed.groupTotal};
}
root.HTImportParser={parse,match,rowsFrom,fixtureLocalDateTime,nameScore,norm,readFixtureId};
})(typeof window!=='undefined'?window:globalThis);
