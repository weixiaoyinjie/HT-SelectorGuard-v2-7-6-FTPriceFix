package com.htlive.monitor;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/** Local-only, separate HT/FT scanner caches. Never contains API credentials or betting actions. */
public final class SelectorSnapshotStore {
    private static final int MAX_JSON_BYTES = 28 * 1024 * 1024;
    private SelectorSnapshotStore() {}
    private static File target(File dir, String mode) throws IOException {
        if (!"HT".equals(mode) && !"FT".equals(mode)) throw new IOException("无效的筛选模式");
        return new File(dir, "selector-screen-" + mode + "-v23.json.gz");
    }

    public static synchronized void save(File dir, String mode, String json) throws IOException {
        File file=target(dir,mode);
        if (json==null||json.length()<2||json.charAt(0)!='{' || json.length()>MAX_JSON_BYTES)
            throw new IOException("候选缓存格式错误或数据过大");
        byte[] bytes=json.getBytes(StandardCharsets.UTF_8);
        if (bytes.length>MAX_JSON_BYTES) throw new IOException("候选缓存超过容量上限");
        File tmp=new File(file.getPath()+".tmp");
        try {
            try(FileOutputStream fos=new FileOutputStream(tmp); GZIPOutputStream gz=new GZIPOutputStream(fos)) {
                gz.write(bytes);
                gz.finish();
                fos.getFD().sync();
            }
            try { Files.move(tmp.toPath(),file.toPath(),StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE); }
            catch(AtomicMoveNotSupportedException e) { Files.move(tmp.toPath(),file.toPath(),StandardCopyOption.REPLACE_EXISTING); }
        } finally { if(tmp.exists())tmp.delete(); }
    }

    public static synchronized String load(File dir, String mode) throws IOException {
        File file=target(dir,mode);
        if(!file.isFile())return "";
        try(GZIPInputStream in=new GZIPInputStream(new FileInputStream(file));
            ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] block=new byte[8192]; int n;
            while((n=in.read(block))!=-1){
                if(out.size()+n>MAX_JSON_BYTES)throw new IOException("候选缓存长度异常");
                out.write(block,0,n);
            }
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }
}
