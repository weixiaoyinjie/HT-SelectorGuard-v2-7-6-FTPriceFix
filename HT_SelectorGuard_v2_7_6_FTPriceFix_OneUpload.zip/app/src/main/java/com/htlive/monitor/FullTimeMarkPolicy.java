package com.htlive.monitor;

/** Pure FT-only timetable gate. Event time is from the football API, not a
 * projection from the scheduled kickoff. Kept separate from legacy HT marks. */
public final class FullTimeMarkPolicy {
    private FullTimeMarkPolicy() {}
    public static boolean due(String period, String status, int minute, long sampleAt, long now, int mark) {
        if(!"FT".equals(period) || !"2H".equals(status))return false;
        if(mark!=60 && mark!=75 && mark!=85)return false;
        if(minute<mark || minute>mark+10)return false;
        return sampleAt>0 && now>=sampleAt && now-sampleAt<=90_000L;
    }
}
