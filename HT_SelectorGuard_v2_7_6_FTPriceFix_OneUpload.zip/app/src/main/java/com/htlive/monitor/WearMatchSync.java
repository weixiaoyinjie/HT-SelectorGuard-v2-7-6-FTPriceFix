package com.htlive.monitor;

import android.content.Context;
import android.util.Log;
import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.Wearable;
import com.google.android.gms.wearable.PutDataMapRequest;
import org.json.JSONArray;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;

/** The phone owns all API polling and risk decisions; the watch mirrors its sampled values. */
public final class WearMatchSync {
    private WearMatchSync() {}
    private static void include(JSONObject from,JSONObject into,String... fields) throws org.json.JSONException {
        if(from==null)return;
        for(String name:fields)if(from.has(name))into.put(name,from.get(name));
    }
    private static JSONObject compactSides(JSONObject value,String... attrs) throws org.json.JSONException {
        JSONObject obj=new JSONObject();
        include(value,obj,attrs);return obj;
    }
    public static JSONObject compact(JSONObject snapshot) {
        JSONObject result=new JSONObject();
        try {
            result.put("v",3).put("updatedAt",snapshot.optLong("updatedAt",0L))
                .put("revisionAt",snapshot.optLong("revisionAt",snapshot.optLong("updatedAt",0L)))
                .put("errorAt",snapshot.optLong("errorAt",0L))
                .put("interval",snapshot.optInt("interval",60))
                .put("error",snapshot.optString("error",""));
            JSONArray rows=snapshot.optJSONArray("matches"),out=new JSONArray();
            if(rows!=null)for(int i=0;i<Math.min(12,rows.length());i++){
                JSONObject m=rows.optJSONObject(i);if(m==null)continue;
                JSONObject copy=new JSONObject();
                include(m,copy,"id","home","away","h","a","minute","status","period",
                    "fixtureSampledAt","lastStatsAt","lastStatsChangedAt","statsSource",
                    "trend","mainPick","dataError","eventError","aiReviewError");
                JSONObject stats=m.optJSONObject("stats");
                if(stats!=null){
                    JSONObject tiny=new JSONObject();include(stats,tiny,"available");
                    for(String side:new String[]{"home","away"})
                        tiny.put(side,compactSides(stats.optJSONObject(side),
                            "shots","on","box","danger","xg"));
                    copy.put("stats",tiny);
                }
                JSONObject risk=m.optJSONObject("guardRisk");
                if(risk!=null){
                    JSONObject tiny=compactSides(risk,"level","title","hit","pending","broken");
                    String reason=risk.optString("reason","");
                    tiny.put("reason",reason.length()>220?reason.substring(0,220)+"…":reason);
                    copy.put("guardRisk",tiny);
                }
                JSONArray bets=m.optJSONArray("guardBets");
                if(bets!=null){
                    JSONArray concise=new JSONArray();
                    for(int b=0;b<Math.min(3,bets.length());b++)
                        concise.put(compactSides(bets.optJSONObject(b),"pick","role","closed"));
                    copy.put("guardBets",concise);
                }
                JSONObject warning=m.optJSONObject("goalWarning");
                if(warning!=null){
                    JSONObject tiny=compactSides(warning,"rating","title");
                    for(String win:new String[]{"five","ten"}){
                        JSONObject window=warning.optJSONObject(win);
                        if(window==null)continue;
                        JSONObject v=new JSONObject();
                        for(String side:new String[]{"home","away"})
                            v.put(side,compactSides(window.optJSONObject(side),
                                "xg","shots","on","box","danger"));
                        tiny.put(win,v);
                    }
                    copy.put("goalWarning",tiny);
                }
                JSONObject review=m.optJSONObject("aiReview");
                if(review!=null)copy.put("aiReview",compactSides(review,
                    "reach","hold","conclusion","risk","action","time"));
                out.put(copy);
            }
            result.put("matches",out);
        }catch(Exception e){Log.w("HTWatch8","Cannot build watch snapshot",e);}
        return result;
    }
    public static void send(Context context,JSONObject snapshot,String nodeId){
        if(snapshot==null)return;
        JSONObject compact=compact(snapshot);
        String json=compact.toString();
        byte[] data=json.getBytes(StandardCharsets.UTF_8);
        // Avoid excessive Wear MessageClient payloads. 12 compact fixtures generally fit.
        if(data.length>55_000){Log.w("HTWatch8","Snapshot too large, no transfer");return;}
        if(nodeId==null){
            // Durable last-known snapshot: reconnecting watch can receive the latest item.
            // The direct MessageClient path below remains the low-latency fast path.
            try{
                PutDataMapRequest request=PutDataMapRequest.create("/scorepath/live");
                request.getDataMap().putString("json",json);
                request.getDataMap().putLong("at",compact.optLong("updatedAt",0L));
                Wearable.getDataClient(context).putDataItem(request.asPutDataRequest().setUrgent())
                    .addOnFailureListener(e->Log.w("HTWatch8","Durable snapshot sync failed",e));
            }catch(Exception e){Log.w("HTWatch8","Wear Data Layer unavailable",e);}
        }
        if(nodeId!=null){
            Wearable.getMessageClient(context).sendMessage(nodeId,"/scorepath/snapshot",data)
                .addOnFailureListener(e->Log.w("HTWatch8","Snapshot transfer failed",e));
        }else{
            Wearable.getNodeClient(context).getConnectedNodes()
                .addOnSuccessListener(nodes->{for(Node node:nodes){
                    Wearable.getMessageClient(context).sendMessage(node.getId(),"/scorepath/snapshot",data)
                        .addOnFailureListener(e->Log.w("HTWatch8","Snapshot send failed",e));
                }})
                .addOnFailureListener(e->Log.w("HTWatch8","No connected watch",e));
        }
    }
}
