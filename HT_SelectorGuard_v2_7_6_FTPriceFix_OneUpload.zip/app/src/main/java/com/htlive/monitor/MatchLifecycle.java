package com.htlive.monitor;

/** Half-time cleanup is status-driven, not wall-clock driven. */
public final class MatchLifecycle {
    private MatchLifecycle() {}
    public static boolean shouldPrune(String status,String period){
        if(!"FT".equals(period))return shouldPrune(status);
        if(status==null)return false;
        switch(status){
            case "FT": case "AET": case "PEN": case "CANC": case "PST":
            case "ABD": case "AWD": case "WO":return true;
            default:return false;
        }
    }
    public static boolean isLive(String status,String period){
        return "1H".equals(status) || ("FT".equals(period)&&"2H".equals(status));
    }
    public static boolean allowsAlerts(String status,int minute,String period,boolean selector){
        return isLive(status,period)&&(!selector||minute>=3);
    }
    public static boolean shouldPrune(String status){
        if(status==null)return false;
        switch(status){
            case "HT": case "2H": case "FT": case "AET": case "PEN":
            case "CANC": case "PST": case "ABD": case "AWD": case "WO":
                return true;
            default: return false;
        }
    }
}
