package com.htlive.monitor;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import java.util.Set;
import java.util.HashSet;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;

/** Watch8-sized bridged alerts; complete analysis stays in the phone history/detail view. */
public final class AlertNotifier {
    private static final String RISK_CHANNEL="ht_watch8_risk_v1";
    private static final String TIME_CHANNEL="ht_watch8_time_v1";
    private AlertNotifier(){}
    private static void channel(Context c){
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel urgent=new NotificationChannel(RISK_CHANNEL,"Watch8 · 重要比分/守分预警",NotificationManager.IMPORTANCE_HIGH);
        urgent.setDescription("用于手表的进球、红牌、命中和守分风险，短标题与三行重点");
        urgent.enableVibration(true);
        urgent.setVibrationPattern(new long[]{0,220,130,220});
        urgent.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
        nm.createNotificationChannel(urgent);
        NotificationChannel marks=new NotificationChannel(TIME_CHANNEL,"Watch8 · 开赛/15/30/40分钟",NotificationManager.IMPORTANCE_HIGH);
        marks.setDescription("用于手表的时间复核提醒，与重要风险预警分开设置");
        marks.enableVibration(true);
        marks.setVibrationPattern(new long[]{0,170});
        marks.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
        nm.createNotificationChannel(marks);
    }
    static void post(Context ctx,String type,String id,JSONObject match,long at,String fallback){
        emit(ctx,type,id,match,at,fallback,true);
    }
    static void update(Context ctx,String type,String id,JSONObject match,long at){
        emit(ctx,type,id,match,at,"",false);
    }
    /** Remove completed fixture notifications, alert history and 4-point snapshots. */
    static void purgeFinished(Context ctx,Set<String> ids){
        if(ids==null || ids.isEmpty())return;
        SharedPreferences p=ctx.getSharedPreferences("ht_monitor",Context.MODE_PRIVATE);
        NotificationManager nm=(NotificationManager)ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        WearAlertRouter.removeFixtures(ctx,ids);
        synchronized(AlertNotifier.class){
            try{
                JSONArray oldAlerts=new JSONArray(p.getString("alerts","[]")),keepAlerts=new JSONArray();
                JSONArray oldPoints=new JSONArray(p.getString("checkpoints","[]")),keepPoints=new JSONArray();
                for(int i=0;i<oldAlerts.length();i++){
                    JSONObject item=oldAlerts.optJSONObject(i);
                    // A legacy notification may lack a fixture ID: preserve it, do not guess.
                    if(item!=null && !ids.contains(item.optString("id")))keepAlerts.put(item);
                }
                for(int i=0;i<oldPoints.length();i++){
                    JSONObject item=oldPoints.optJSONObject(i);
                    if(item!=null && !ids.contains(item.optString("id")))keepPoints.put(item);
                }
                JSONObject mainPicks=new JSONObject(p.getString("mainPicks","{}"));
                JSONObject guardBets=new JSONObject(p.getString("guardBets","{}"));
                for(String id:ids){mainPicks.remove(id);guardBets.remove(id);}
                SharedPreferences.Editor edit=p.edit().putString("mainPicks",mainPicks.toString())
                    .putString("alerts",keepAlerts.toString())
                    .putString("checkpoints",keepPoints.toString())
                    .putString("guardBets",guardBets.toString());
                for(String id:ids){
                    JSONArray posted=new JSONArray(p.getString("notice_ids_"+id,"[]"));
                    for(int i=0;i<posted.length();i++)nm.cancel(posted.optInt(i));
                    edit.remove("notice_ids_"+id).remove("guard_pending_"+id);
                    edit.remove("delivered_"+id+"_0");
                    edit.remove("delivered_"+id+"_3");
                    for(int minute:AlertPolicy.MARKS)edit.remove("delivered_"+id+"_"+minute);
                    for(int minute:new int[]{60,75,85})edit.remove("delivered_"+id+"_"+minute);
                }
                edit.commit();
            }catch(Exception ex){android.util.Log.w("HT","Finished record cleanup",ex);}
        }
    }
    private static boolean emit(Context ctx,String type,String id,JSONObject match,long at,String fallback,boolean recordHistory){
        try {
            channel(ctx);
            String detail=match==null?fallback:MatchData.detail(match,at,match!=null&&"FT".equals(match.optString("period"))?"API-FOOTBALL 全场统计":"API-FOOTBALL 上半场统计");
            if(detail==null||detail.isEmpty())detail="实时数据暂不可用，请检查接口和比分。";
            String title=(match!=null&&"FT".equals(match.optString("period"))?"【全场】":"")+type+" · "+(match!=null?match.optString("home","主队")+" vs "+match.optString("away","客队"):"比赛 #"+id);
            String expanded=match==null?fallback:MatchData.notificationBody(match,at);
            if(match!=null && fallback!=null && !fallback.trim().isEmpty()){
                expanded="事件依据："+fallback+"\n"+expanded;
                detail="事件依据："+fallback+"\n\n"+detail;
            }
            int nid=6200+Math.abs((id+":"+type).hashCode()%800_000);
            // A match notification must open its own native detail, not MainActivity.
            // This remains reliable during a cold start and while the WebView is still loading.
            Intent open=new Intent(ctx,DetailPopupActivity.class);
            open.setAction("MATCH_DETAIL_"+nid);
            open.setData(android.net.Uri.parse("htscore://fixture/"+id+"/notice/"+nid));
            open.putExtra("id",id);
            open.putExtra("title",title);
            open.putExtra("detail",detail);
            open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent pi=PendingIntent.getActivity(ctx,nid,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            Intent acknowledge=new Intent(ctx,GuardActionReceiver.class);
            acknowledge.setAction("GUARD_ACK").putExtra("id",id);
            PendingIntent ack=PendingIntent.getBroadcast(ctx,Math.abs(("ack_"+id).hashCode()),
                acknowledge,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            Watch8NotificationFormatter.Message watch=Watch8NotificationFormatter.format(type,match,at,fallback);
            Notification.Builder builder=new Notification.Builder(ctx,watch.timed?TIME_CHANNEL:RISK_CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title).setContentText(watch.preview)
                .setStyle(new Notification.BigTextStyle().bigText(expanded))
                .setPriority(Notification.PRIORITY_HIGH)
                .setCategory(watch.timed?Notification.CATEGORY_REMINDER:Notification.CATEGORY_EVENT)
                .setVisibility(Notification.VISIBILITY_PRIVATE).setAutoCancel(true)
                .setLocalOnly(false).setOngoing(false)
                .setOnlyAlertOnce(!recordHistory).setContentIntent(pi)
                .setWhen(System.currentTimeMillis()).setShowWhen(false);
            // One acknowledgement action is retained for alerts that can repeat.
            // The redundant "view details" button is omitted: tapping the banner already opens phone detail.
            if(!watch.timed){
                builder.addAction(new Notification.Action.Builder(
                    android.R.drawable.checkbox_on_background,"已查看 · 停止重复",ack).build());
            }
            // Handset notification is posted immediately, native Watch8 card if acknowledged;
            // otherwise Android's regular notification bridge is enabled automatically.
            WearAlertRouter.deliver(ctx,builder,nid,
                Watch8CompanionPayload.create(id,nid,type,match,at,fallback,recordHistory,
                    title,watch.preview,expanded,detail));
            if(recordHistory){
                // Per-fixture bookkeeping also lets the HT cleanup cancel all old banners.
                synchronized(AlertNotifier.class){
                    SharedPreferences p=ctx.getSharedPreferences("ht_monitor",Context.MODE_PRIVATE);
                    JSONArray prev=new JSONArray(p.getString("alerts","[]")),list=new JSONArray();
                    list.put(new JSONObject().put("id",id).put("time",System.currentTimeMillis()).put("title",title).put("detail",expanded));
                    for(int i=0;i<Math.min(79,prev.length());i++)list.put(prev.get(i));
                    JSONArray sent=new JSONArray(p.getString("notice_ids_"+id,"[]"));
                    boolean found=false;
                    for(int i=0;i<sent.length();i++)if(sent.optInt(i)==nid){found=true;break;}
                    if(!found)sent.put(nid);
                    p.edit().putString("alerts",list.toString()).putString("notice_ids_"+id,sent.toString()).apply();
                }
            }
            return true;
        }catch(Exception e){ android.util.Log.e("HT","Failed to post alert",e); return false; }
    }
    /** Exactly one confirmed start reminder per selector-managed fixture, even if
     * Android's scheduled start is late. Both phone and Watch8 use the original
     * notification routing; this is not a new alert channel or separate engine. */
    static synchronized boolean postSelectorStart(Context ctx,String id,JSONObject match,long at){
        if(match==null || !AlertPolicy.selectorMinuteThreeFresh(System.currentTimeMillis(),
            match.optLong("fixtureSampledAt",0L),match.optString("status"),
            match.optInt("minute",-1)))return false;
        if(!SelectorMonitorSync.isSelectedFixture(ctx,id))return false;
        SharedPreferences p=ctx.getSharedPreferences("ht_monitor",Context.MODE_PRIVATE);
        String key="delivered_"+id+"_3";
        if(p.getBoolean(key,false))return false;
        NotificationManager manager=(NotificationManager)ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        // A blocked notification is not successful delivery. Keep the pending
        // reminder eligible after the user grants notification permission.
        if(manager==null || !manager.areNotificationsEnabled())return false;
        int minute=match.optInt("minute",-1);
        String title=minute<=4?"⏱ 第3分钟 · 预警监控已启动":"⚠ 第3分钟启动提醒延迟";
        String reason=minute<=4?
            "API确认实际比赛已达到第3分钟；本场进入已勾选的半场/全场预警模式。":"API确认比赛已到第"+minute+"分钟；设备唤醒或接口更新延迟，现已启动。此前消息可能漏报，请立即核对比赛和投注。";
        if(!emit(ctx,title,id,match,at,reason,true))return false;
        if(!p.edit().putBoolean(key,true).commit())return false;
        saveCheckpoint(ctx,id,3,match,at);
        return true;
    }

    /** FT-only second-half checkpoints. Existing HT kickoff/15/30/40 reminders
     * remain untouched. Do not mark a checkpoint delivered BEFORE emit succeeds. */
    static synchronized boolean postFullTimeMark(Context ctx,String id,int mark,JSONObject match,long at){
        if(match==null)return false;
        int minute=match.optInt("minute",-1);
        if(!FullTimeMarkPolicy.due(match.optString("period"),match.optString("status"),
            minute,match.optLong("fixtureSampledAt",0L),at,mark))return false;
        SharedPreferences p=ctx.getSharedPreferences("ht_monitor",Context.MODE_PRIVATE);
        String key="delivered_"+id+"_"+mark;
        if(p.getBoolean(key,false))return false;
        NotificationManager manager=(NotificationManager)ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if(manager==null || !manager.areNotificationsEnabled())return false;
        String note=minute>mark+2?
            "原定第"+mark+"分钟，现收到第"+minute+"分钟实时数据（延迟补报）；请检查最新状态。":
            "全场三张比分单；复核当前比分、近5/10分钟攻势、全场累计统计、剩余时间及手填结算报价。";
        if(!emit(ctx,"⏱ 第"+mark+"分钟 · 全场比分路径复核",id,match,at,note,true))return false;
        if(!p.edit().putBoolean(key,true).commit())return false;
        saveCheckpoint(ctx,id,mark,match,at);
        return true;
    }

    /** Kickoff + three timestamped 15/30/40 reminders, removed at verified halftime. */
    public static void saveCheckpoint(Context ctx,String id,int mark,JSONObject match,long at){
        try{
            SharedPreferences p=ctx.getSharedPreferences("ht_monitor",Context.MODE_PRIVATE);
            JSONArray old=new JSONArray(p.getString("checkpoints","[]")),updated=new JSONArray();
            JSONObject c=new JSONObject().put("id",id).put("mark",mark)
                .put("capturedAt",System.currentTimeMillis())
                .put("sourceAt",match!=null && match.optLong("lastStatsAt",0)>0?match.optLong("lastStatsAt"):at)
                .put("status",match==null?"?":match.optString("status","?"))
                .put("minute",match==null?-1:match.optInt("minute",-1))
                .put("home",match==null?"":match.optString("home",""))
                .put("away",match==null?"":match.optString("away",""))
                .put("score",match==null?"?":match.optString("h","?")+"-"+match.optString("a","?"))
                .put("trend",match==null?"无可用样本":match.optString("trend","无可用样本"))
                .put("sampleMissing",match==null || match.optLong("lastStatsAt",0)<=0 || at-match.optLong("lastStatsAt",0)>90_000L)
                .put("cashout","未接入平台结算报价，无法计算各单结算金额");
            if(match!=null){
                JSONObject stats=match.optJSONObject("stats"),delta=match.optJSONObject("delta");
                if(stats!=null)c.put("stats",stats);
                if(delta!=null)c.put("delta",delta);
                JSONObject warning=match.optJSONObject("goalWarning");
                if(warning!=null)c.put("goalWarning",warning);
                JSONObject ai=match.optJSONObject("aiReview");
                if(ai!=null)c.put("aiReview",ai);
                JSONObject guard=match.optJSONObject("guardRisk");
                if(guard!=null)c.put("guardRisk",guard);
                JSONArray bets=match.optJSONArray("guardBets");
                if(bets!=null)c.put("guardBets",bets);
            }
            updated.put(c);
            for(int i=0;i<old.length() && updated.length()<80;i++){
                JSONObject item=old.optJSONObject(i);
                if(item==null || (id.equals(item.optString("id")) && mark==item.optInt("mark")))continue;
                updated.put(item);
            }
            p.edit().putString("checkpoints",updated.toString()).apply();
        }catch(Exception e){android.util.Log.w("HT","save checkpoint",e);}
    }
    static boolean postKickoff(Context ctx,String id,JSONObject match,long at){
        if(match==null || !AlertPolicy.kickoffFresh(
            System.currentTimeMillis(),match.optLong("fixtureSampledAt",0L),
            match.optString("status"),match.optInt("minute",-1)))return false;
        SharedPreferences p=ctx.getSharedPreferences("ht_monitor",Context.MODE_PRIVATE);
        String key="delivered_"+id+"_0";
        if(p.getBoolean(key,false))return false;
        if(!p.edit().putBoolean(key,true).commit())return false;
        saveCheckpoint(ctx,id,0,match,at);
        boolean stale=match.optJSONObject("stats")==null ||
            !match.optJSONObject("stats").optBoolean("available",false) ||
            match.optLong("lastStatsAt",0L)<=0 ||
            System.currentTimeMillis()-match.optLong("lastStatsAt",0L)>90_000L;
        post(ctx,"⚽ 比赛开始 · 赛况基线",id,match,at,
            stale?"比赛已开始；统计数据暂缺，请勿将0-0当作守分安全依据。":"比赛已开始；建立本场数据基线，后续追加15/30/40分钟复核提醒。");
        return true;
    }
    static boolean postMark(Context ctx,String id,int mark,JSONObject match,long at){
        if(match==null || !AlertPolicy.checkpointFresh(
            System.currentTimeMillis(),match.optLong("fixtureSampledAt",0L),
            match.optString("status"),match.optInt("minute",0),mark))return false;
        SharedPreferences p=ctx.getSharedPreferences("ht_monitor",Context.MODE_PRIVATE);
        String key="delivered_"+id+"_"+mark;
        if(p.getBoolean(key,false))return false;
        if(!p.edit().putBoolean(key,true).commit())return false;
        saveCheckpoint(ctx,id,mark,match,at);
        boolean stale=match==null || match.optJSONObject("stats")==null ||
            !match.optJSONObject("stats").optBoolean("available",false) ||
            match.optLong("lastStatsAt",0L)<=0 ||
            System.currentTimeMillis()-match.optLong("lastStatsAt",0L)>90_000L;
        post(ctx,"第"+mark+"分钟定点复核 · 非强制结算",id,match,at,
            stale?"当前比赛统计缺失或滞后，请检查最新数据，不应依据旧数据判断。":"");
        return true;
    }
}
