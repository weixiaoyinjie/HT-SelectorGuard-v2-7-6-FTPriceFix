# v2.7.6 FTPriceFix
- Fix cached HT zero-score cards: opening FT research automatically requests the visible upcoming fixtures' FT odds, including cold start and visible count changes.
- Full FT scan queries visible FT prices before historical research. Per-fixture requests, targeted market fallback, and unfiltered bookmaker fallback (locally validates Bet365 and exact FT markets).
- Distinguish pending / provider no quote / API error; log returned Bet365 market IDs and names without credentials. No substitute price.
- Keep original UI structure, HT engine, native phone/watch notifications and historical FT research engine. Refreshing an existing quote updates price-dependent cost and downgrades prior B until full research is repeated.
- 29 JS test files passed, including mocked cache-trigger and API fallback. No live authenticated API or Android build verified.
