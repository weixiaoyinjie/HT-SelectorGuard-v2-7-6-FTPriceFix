# GitHub新仓库上传说明（v2.2）

建议创建 Private 仓库：`HT-SelectorGuard-Watch8-v2-2`。

**电脑方案**：解压 `HT_SelectorGuard_v2_2_FT_LowScore_60_75_85_NewRepo.zip` 并将解压出的所有内容（包括隐藏的 `.github/` 目录）放到新仓库根目录，提交后 Actions → Build Watch8 44mm Phone and Wear APKs → Run workflow。

**手机方案**：在新仓库根目录只上传 `HT_SelectorGuard_v2_2_FT_LowScore_60_75_85_NewRepo.zip`，另外在仓库新建 `.github/workflows/build-apk.yml`（复制单独提供的编译 YAML 文件内容）。上传 ZIP 本身不能自动触发 GitHub Actions。运行后下载 PHONE 与 WATCH 两份 APK。

注意：这里提供完整源码，不是 APK。请先备份手机原配置和两端安装包，实机检查第3分钟、上半场15/30/40、全场下半场60/75/85、通知权限与手表送达。源代码包含用于测试签名的 JKS；只放 Private 仓库，勿作为正式产品签名。
